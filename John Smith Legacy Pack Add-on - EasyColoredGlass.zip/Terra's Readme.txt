===================================================================================================

John Smith Legacy Resource Pack Add-on: "Easy Colored Glass"
Author: xXTerra_BranfordXx
Version: 0.9.8 Alpha Release Build
Release Date: 3rd October, 2013

For Use only with Minecraft 1.6.2 and 1.6.4

===================================================================================================

First, to get the most out of this Resource Pack Add-on, it is suggested you
download the latest version of the John Smith Legacy Resource Pack from: http://www.jslegacy.com/

You will also need to download Cpt.SpaceToaster's "Easy Colored Glass" Forge mod from:
http://www.minecraftforum.net/topic/1965760-164forge-colored-glass/

===================================================================================================

-Introduction--------------------------------------------------------------------------------------

Have you ever wanted colored glass, in the world of Minecraft? Have you also wanted that colored
glass to match the John Smith Texture Pack? If so, you are in luck, my friend, because that's what
this Resource Pack Add-on is all about. Simply follow the installation instructions, and enjoy a
new world full of color, brought to you by the John Smith Legacy Pack and Easy Colored Glass mod!

-Features------------------------------------------------------------------------------------------

> Transparent Colored Glass Blocks/Panes, and Colored Sand.
> Connected Textures for Glass Blocks, to remove the "frame" from individual blocks.
> Removed the "lattice" designs from the main Resource Pack, as well as in my Add-on.

-Requirements--------------------------------------------------------------------------------------

> A copy of Minecraft 1.6.2 or 1.6.4 Jar
> MCPatcher or Optifine
> Minecraft Forge
> John Smith Legacy Pack
> John Smith Legacy Pack Add-on - EasyColoredGlass


-Installation Instructions-------------------------------------------------------------------------

Before you can make use of this Resource Pack Add-on, you will need to patch Minecraft to make use
of HD Textures and features, either using MCPatcher, or Optifine. It is highly recommended you do
not use both MCPatcher and Optifine on the same version of your Minecraft jar, due to several bugs
that may occur.

I recommend MCPatcher, due to it's ease of use and ability to add Jar mods via the patcher feature.

Download MCPatcher here:
http://www.minecraftforum.net/topic/1496369-13w39b-164-and-earlierupdate-928-mcpatcher-hd-fix-422/

Because "Easy Colored Glass" mod requires Forge, you will need to install Forge before you can use
it. You can either use the official Forge installer, or you can use LiteMod's "Cascaded Tweaks"
feature to install it. Personally, I prefer to use LiteLoader, but the choice is yours.

Next, download the "Easy Colored Glass" mod, from the Minecraft forums (see the above link), and
place it in your "/mods/" folder.

Once you have patched your 1.6.2/1.6.4 version of the Minecraft Jar with MCPatcher, and Forge, and
added the Easy Colored Glass mod to your /mods/ folder, you are ready to place this Resource Pack
Add-on into your John Smith Legacy .zip file!

-Advanced Installation Instructions----------------------------------------------------------------

Because this is an "Add-on", there are slightly different instuctions for how to use it. But if you
follow these simple instructions, you'll be just fine.

First, if you're reading this text, it's obvious you know how to open archive files. To make things
easier, you should extract the contents of this .zip file to any location on your harddrive, so
you're not working with multiple archives. You should see an "/assets/" folder in my .zip file,
and in the "/assets/" folder, an "/easycoloredglass/" folder and a "/minecraft/" folder.

Before you do anything, I suggest you make a backup copy of your original John Smith Legacy Pack
.zip file. This is just in case something goes wrong, so you don't end up having to redownload the
files again. This is just a precaution, but I still suggest you do it.

Next, open your copy of the John Smith Legacy Pack with either WinRAR, 7-Zip, or any other archive
utility. It doesn't really matter, as long as it can open/extract/append a .zip file. You do not
have to extract the contents of the John Smith Legacy Pack to another location. You can directly
copy over files from this Add-on, without having to repack the .zip file. Just append the files,
and all appropriate files will transfer to the correct locations and overwrite existing files.

You will see the usual contents: an "/assets/" folder, text files, and the Pack properties and
image files. If you wish, you can drag a copy of this "Read me" into this directory. If you don't
want to, it won't effect anything, it's just for future reference, or if you decide to share this
Add-on with friends. But it would be nice if you included the Read me file, for the credits.

If you enter the "/assets/" folder, you should see only a "/minecraft/" folder. This applies to the
default John Smith Legacy Pack, and not to any of the "Mod Support" packs that exist. If you have
any other folders in your "/assets/" folder, it shouldn't present a problem.

Before we add the colored glass textures, you'll want to append the existing Glass Block and Pane
textures, to match with the new textures. I did not like seeing lattice work on the glass, and felt
that 100% transparent glass was a much nicer option. If you don't wish to change the glass, that's
not a problem, but the transparent glass will not "match" the colored glass, unless you decide to
add the lattice designs to the new tiles (all seven hundred and fifty-two of them!).

If you choose to retain the "original" glass textures, skip the next step, otherwise, continue.

Enter the "/assets/" folder of "John Smith Legacy Pack Add-on - EasyColoredGlass", and copy over
the "/minecraft/" folder, into the "/assets/" folder in the "John Smith Legacy Pack" file you
are modifying. This should overwrite the original Glass Block textures, and CTM details, and give
you 100% transparent glass. You will still have a decorative frame outline on Glass Blocks and
Panes, but connected glass will omit that frame on the parts where the glass touches another
block of glass. It's pretty neat looking, and handy for making "invisible barriers".

Next, while in the "/assets/" folder of "John Smith Legacy Pack Add-on - EasyColoredGlass", drag
the "easycoloredglass" folder into the "/assets/" folder in the "John Smith Legacy Pack". This will
now tell Minecraft to look inside this extra assets folder, to look for all texture files relating
to the "Easy Colored Glass" mod.

The "/easycoloredglass/" folder contains two sub-folders: "/mcpatcher/" and "/textures/". These
folders contain all of the image tiles required to reskin the default textures of the Easy Colored
Glass mod to reflect the style and feel of John Smith's textures. There are also advanced
instructions in the CTM folder, for how to handle any Block ID issues, or texture problems you may
encounter.

You can feel free to apply the lattice designs of the original John Smith Legacy Pack's glass onto
these tiles if you really want to. I don't intend to do so myself because I want 100% transparency.

-Current issues------------------------------------------------------------------------------------

At present, this Add-on does not support the ability to connect Glass Panes to one another, and
have the "frame" vanish, for Glass Panes that are in direct contact with one another. It is likely
an issue with how the Easy Colored Glass mod renders Glass Panes, or there may be another factor at
play (I've obviously spent a great deal of time trying every method I could think of, to edit the
"block3881.properties" file in CTM with different values to try and get these textures to connect).

You will also notice that ALL "transparent textures" (Water, Ice Blocks, other Coloured Glass) that
are behind the Coloured Glass introduced with this mod, will turn "invisible". This issue is well
known, and not a result of either the mod, nor my Resource Pack Add-on. Cpt.SpaceToaster is already
aware of the issue (and mentions it in the first post of the mod's thread), and there doesn't seem
to be any solution to this "issue" at present. It even happens in the "Minecraft 2.0 April Fools!"
edition that came out this year.

-Usage and Copyright-------------------------------------------------------------------------------

As this is an "Add-on Pack" created solely for the purpose of enhancing the John Smith Legacy Pack,
I don't mind other members of the community using these new textures in their Resource Packs, Mods,
or anything else that you choose to use it in (heck, it would be neat to see these textures used by
as many people as possible!). Just be respectful, and give credit for the colored tiles to me, if
you decide to share this Add-on. These textures took several hours to get ~just right~, and it'd be
really rude to just take credit for doing it all yourself.

So some "Dos" and "Don'ts".

> Do include the "Terra's Readme" file in your modified pack. You can rename it if you really
like, but don't change the contents of this file. Leave it as it is, and it'll make me happy.

> Do share it with all of your friends! Encourage everyone you know, who loves the John Smith
textures to give "Easy Colored Glass" a chance, and to use these new textures! That way you're
giving more exposure to the mod, the original Resource Pack, and my Add-on. Win-win for us all!

> Do link to the original mediafire link. I want to see how many people are downloading this. If
you insist on uploading it to a mirror site, please at least post a link to the original.

> Do NOT upload this to ANY website that generates revenue for downloads. If I'm not doing so, due
to the fact that the base Glass Block template is derived directly from John Smith's original work,
then you shouldn't. The reason for this, is out of respect for John Smith, and the community pack.

> Do NOT take credit for my work. It's rude, and just not cool.

> Do NOT look directly into the sun, you'll hurt your eyes.

> Do enjoy this Add-on. It was a lot of work, but if even one person loves it as much as I do, I'll
be really happy that I decided to go public with it. It would tickle me pick to see it in use!

> Do try to fix the block3881.properties issue that is preventing connected texture support from
working on the Glass Panes. I'll give you 100% credit for it, and I'll finally be able to stop
going crazy trying to figure out why it's not working the way it's supposed to.

> Do feel free to make revisions to the colors if they aren't to your liking. I tried to keep the
Sand Blocks looking like a blend between the regular Sand block textures, with the color scheme of
Clay Blocks, and the vibrancy of the old Wool blocks. But you can make them darker, or lighter, or
even make different colors for the blocks, if you like. I also tried to have a little more color
separation with the colored Glass Blocks, where the Black, Dark Gray, Light Gray and "clear" blocks
are concerned, while also giving it a "tinted window" effect. I think people may like it, but some
might want "true" Dark Gray and Light Gray blocks, and that's perfectly fine. Edit the blocks as
much as you want.

-Credits-------------------------------------------------------------------------------------------

-xXTerra_BranfordXx (principle texture colours and re-tiles)
-CptSpaceToaster (for "Easy Colored Glass" mod, which inspired this Add-on!)
-John Smith (for the original texture pack, and inspiring me to create my own textures)

Additional thanks to all of the People who helped with the main Resource Pack

- flying sheep
- JimStoneCraft
- Greenhawk837
- iTpyn
- PwnyBrony32
- Codiferus17
- _DRYBONES_
- Nehaw55
- EchoZeero
- WaterTipper
- Necron 1992
- Soulburner
-Typodermic Fonts (for the Berylium font - http://typodermicfonts.com/berylium-font-spruced-up/)
-Nuin and JimStoneCraft for Importing to Minecraft on the main Resource Pack
-RedSolar for the Sheep Colours on the main Resource Pack

And everyone who has ever posted a texture file to the forums! This community pack would not exist
if not for all the people who have contributed to it! So thank you, everyone!

===================================================================================================